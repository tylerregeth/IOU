﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace IOU
{
    [Activity(Label = "Register", MainLauncher = true)]
    public class RegisterActivity : Activity
    { 
        EditText txtRegisterUsername;
        EditText txtRegisterPassword;
        EditText txtFirstName;
        EditText txtLastName;
        EditText txtRegisterEmail;
        EditText txtBankName;
        EditText txtAccountNum;
        EditText txtRoutingNum;
        Button btnCompleteRegistration;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            txtRegisterUsername = FindViewById<EditText>(Resource.Id.txtRegisterUsername);
            txtRegisterPassword = FindViewById<EditText>(Resource.Id.txtRegisterPassword);
            txtFirstName = FindViewById<EditText>(Resource.Id.txtFirstName);
            txtLastName = FindViewById<EditText>(Resource.Id.txtLastName);
            txtRegisterEmail = FindViewById<EditText>(Resource.Id.txtRegisterEmail);
            txtBankName = FindViewById<EditText>(Resource.Id.txtBankName);
            txtAccountNum = FindViewById<EditText>(Resource.Id.txtAccountNum);
            txtRoutingNum = FindViewById<EditText>(Resource.Id.txtRoutingNum);
            btnCompleteRegistration = FindViewById<Button>(Resource.Id.btnCompleteRegistration);

            btnCompleteRegistration.Click += BtnCompleteRegistration_Click;
        }

        private void BtnCompleteRegistration_Click(object sender, EventArgs e)
        {
            SetContentView(Resource.Layout.Transactions);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace IOU
{
    [Activity(Label = "TransactionsActivity")]
    public class TransactionsActivity : Activity
    {
        EditText txtPayUser;
        EditText txtReason;
        EditText txtAmount;
        EditText txtDate;
        Button btnReminder;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here

            txtPayUser = FindViewById<EditText>(Resource.Id.txtPayUser);
            txtReason = FindViewById<EditText>(Resource.Id.txtReason);
            txtAmount = FindViewById<EditText>(Resource.Id.txtAmount);
            txtDate = FindViewById<EditText>(Resource.Id.txtDate);
            btnReminder = FindViewById<Button>(Resource.Id.btnReminder);
        }
    }
}